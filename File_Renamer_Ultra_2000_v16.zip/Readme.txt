How To Install File Renamer Ultra 2000
On Modern Machines

1. Run "File Renamer Ultra 2000 v15 beta.exe" installation program
2. Double-click to import "FRU2000 Startup Error Fix.reg"
3. Copy the contents (FRU2000.EXE/GID/HLP) of the "FRU2000 16 Update" folder to the installation folder from step 1
4. Right-click and Run as Administrator the "Install.cmd" file in the "WinHelp" folder
